#include <stdio.h>
#include <stdlib.h>
#include "Person.h"


int main()
{
    Person* personArray[50];
    int i,edad;

    for(i = 0; i < 10; i++)
    {
        printf("ingrese la edad: \n");
        scanf("%d",&edad);
        personArray[i] = person_new(i,i);
        person_setAge(personArray[i],edad);
    }
    for(i = 0; i < 10; i++)
    {
        person_setAge(personArray[i],i-4);
    }
    for(i = 0; i < 10; i++)
    {
        printf("\nAge: %2d",person_getAge(personArray[i]));
    }
    scanf(" ");
    return 0;
}

